click_address = "127.0.0.1"
cluster_name = "example_cluster"

